#!/bin/bash
# Vocal Remover for the Mac: double-click this file. It checks the program files, lets macOS run them
# (they are not signed by a company) and starts the program, whose window opens in your browser.
cd "$(dirname "$0")" || exit 1
if [ "$(uname -m)" != "arm64" ]; then
  echo "This Vocal Remover runs on Apple silicon Macs (M1 and later). This Mac reports: $(uname -m)."
  read -r -p "Press Enter to close."
  exit 1
fi
# The expected checksums are written in by the release build; a changed or damaged file is not started.
PROGRAM_SHA256="e388ce43ab37eccbf7dcc54c7708f545328502410b9f597520aeb69b5d689832"
LIBRARY_SHA256="bcc9110f9d638a119de2db7afb3ba9a1da8085f0cb3401e1c48ae1caf450b6fa"
check() {
  local want="$2" got
  got=$(shasum -a 256 "$1" | cut -d' ' -f1)
  if [ "$got" != "$want" ]; then
    echo "$1 is not the file that was shipped (checksum $got). Download the Vocal Remover again."
    read -r -p "Press Enter to close."
    exit 1
  fi
}
check VocalRemover "$PROGRAM_SHA256"
check libonnxruntime.dylib "$LIBRARY_SHA256"
chmod +x VocalRemover 2>/dev/null
# Both files were just checked against their checksums, so it is safe to release them from the download
# quarantine; without this macOS refuses to start an unsigned program with "cannot be opened".
xattr -d com.apple.quarantine VocalRemover libonnxruntime.dylib 2>/dev/null
# Switch off ONNX Runtime's usage reporting to Microsoft. The program sets this too, before it loads the
# library; setting it here as well makes sure it is in place from the very start.
export ORT_DISABLE_TELEMETRY=1
./VocalRemover "$@"
echo
read -r -p "Vocal Remover has stopped. Press Enter to close this window."
