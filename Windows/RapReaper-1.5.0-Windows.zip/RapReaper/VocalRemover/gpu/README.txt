The graphics-processor runtime, used only when the graphics processor is switched on:
onnxruntime.dll is Microsoft's ONNX Runtime 1.24.4 built with DirectML (NuGet package
Microsoft.ML.OnnxRuntime.DirectML) and DirectML.dll is Microsoft's DirectML 1.15.4 (NuGet
package Microsoft.AI.DirectML), both unchanged. Their licences are in ..\licenses.
